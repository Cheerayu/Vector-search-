from typing import List, Dict, Any, Optional, Any as AnyType
import uuid
from qdrant_client import QdrantClient, models


def connect(url: str = "http://localhost:6333", api_key: Optional[str] = None) -> QdrantClient:
    return QdrantClient(url=url, api_key=api_key)  # [web:224]


def _hnsw_diff(m: int, ef_construct: int, full_scan_threshold: int) -> models.HnswConfigDiff:
    return models.HnswConfigDiff(m=m, ef_construct=ef_construct, full_scan_threshold=full_scan_threshold)  # [web:224]


def ensure_hybrid_collection(
    client: QdrantClient,
    name: str,
    dense_name: str,
    dense_size: int,
    colbert_name: Optional[str] = None,
    colbert_size: Optional[int] = None,
    distance: str = "COSINE",
    m: int = 32,
    ef_construct: int = 256,
    full_scan_threshold: int = 10000,
) -> None:
    dist = getattr(models.Distance, distance)
    vectors: Dict[str, Any] = {
        dense_name: models.VectorParams(
            size=dense_size,
            distance=dist,
            hnsw_config=_hnsw_diff(m, ef_construct, full_scan_threshold),
        )
    }  # [web:224]

    if colbert_name and colbert_size:
        vectors[colbert_name] = models.VectorParams(
            size=colbert_size,
            distance=dist,
            hnsw_config=_hnsw_diff(m, ef_construct, full_scan_threshold),
            multivector_config=models.MultiVectorConfig(
                comparator=models.MultiVectorComparator.MAX_SIM
            ),
        )  # [web:224]

    sparse_cfg = {"sparse": models.SparseVectorParams(index=models.SparseIndexParams(on_disk=True))}  # [web:224]

    try:
        client.get_collection(name)
        client.update_collection(
            collection_name=name,
            vectors_config={k: models.VectorParamsDiff(hnsw_config=_hnsw_diff(m, ef_construct, full_scan_threshold)) for k in vectors.keys()},
            sparse_vectors_config=sparse_cfg,
        )  # [web:224]
    except Exception:
        client.create_collection(
            collection_name=name,
            vectors_config=vectors,
            sparse_vectors_config=sparse_cfg,
        )  # [web:224]


def _upsert_points_batched(client: QdrantClient, name: str, points: List[models.PointStruct], batch_size: int = 64) -> None:
    # Smaller batches to stay well under the 32 MB JSON body default limit [web:401]
    for i in range(0, len(points), batch_size):
        batch = points[i:i + batch_size]
        client.upsert(collection_name=name, points=batch)  # [web:224]


def upsert_hybrid(
    client: QdrantClient,
    name: str,
    dense_name: str,
    dense_vectors: List[List[float]],
    payloads: List[Dict[str, Any]],
    sparse_docs: Optional[List[models.Document]] = None,
    colbert_name: Optional[str] = None,
    colbert_vectors: Optional[List[List[List[float]]]] = None,
    ids: Optional[List[AnyType]] = None,
) -> None:
    points: List[models.PointStruct] = []
    for i, payload in enumerate(payloads):
        vecs: Dict[str, Any] = {dense_name: dense_vectors[i]}
        if sparse_docs:
            vecs["sparse"] = sparse_docs[i]
        if colbert_name and colbert_vectors:
            vecs[colbert_name] = colbert_vectors[i]
        pid = ids[i] if (ids and ids[i] is not None) else str(uuid.uuid4())
        points.append(models.PointStruct(id=pid, vector=vecs, payload=payload))
    _upsert_points_batched(client, name, points, batch_size=64)  # [web:401]


def _by_id_maxscore(sets: List[List[models.ScoredPoint]], top_k: int) -> List[models.ScoredPoint]:
    best: Dict[Any, models.ScoredPoint] = {}
    for lst in sets:
        for p in lst or []:
            if p is None:
                continue
            pid = p.id
            if pid not in best or (p.score or 0.0) > (best[pid].score or 0.0):
                best[pid] = p
    return sorted(best.values(), key=lambda sp: (sp.score or 0.0), reverse=True)[:top_k]  # [web:224]


def _query_dense(client: QdrantClient, name: str, using: str, qvec: List[float], k: int, ef: int) -> List[models.ScoredPoint]:
    resp = client.query_points(
        collection_name=name,
        query=qvec,
        using=using,
        limit=k,
        with_payload=True,
        with_vectors=False,
        search_params=models.SearchParams(hnsw_ef=ef, exact=False),
    )  # [web:224]
    return getattr(resp, "points", [])


def _query_sparse_only(client: QdrantClient, name: str, doc: models.Document, k: int) -> List[models.ScoredPoint]:
    resp = client.query_points(
        collection_name=name,
        query=doc,
        using="sparse",
        limit=k,
        with_payload=True,
        with_vectors=False,
    )  # [web:224]
    return getattr(resp, "points", [])


def _query_colbert(client: QdrantClient, name: str, using: str, tokens: List[List[float]], k: int, ef: int) -> List[models.ScoredPoint]:
    resp = client.query_points(
        collection_name=name,
        query=tokens,
        using=using,
        limit=k,
        with_payload=True,
        with_vectors=False,
        search_params=models.SearchParams(hnsw_ef=ef, exact=False),
    )  # [web:224]
    return getattr(resp, "points", [])


def query_hybrid(
    client: QdrantClient,
    name: str,
    dense_name: str,
    query_dense: List[float],
    top_k: int = 5,
    hnsw_ef: int = 128,
    query_sparse: Optional[models.Document] = None,
    colbert_name: Optional[str] = None,
    query_colbert: Optional[List[List[float]]] = None,
) -> List[models.ScoredPoint]:
    legs: List[List[models.ScoredPoint]] = []
    legs.append(_query_dense(client, name, dense_name, query_dense, top_k, hnsw_ef))  # [web:224]
    if query_sparse is not None:
        legs.append(_query_sparse_only(client, name, query_sparse, top_k))  # [web:224]
    if colbert_name and query_colbert is not None:
        legs.append(_query_colbert(client, name, colbert_name, query_colbert, top_k, hnsw_ef))  # [web:224]
    return _by_id_maxscore(legs, top_k)  # [web:224]
