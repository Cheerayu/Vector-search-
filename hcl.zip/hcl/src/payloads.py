from typing import Dict, Any, List

# Keep payloads compact; snippet only
MAX_SNIPPET_CHARS = 800  # reduced to shrink JSON request size [web:368]

def make_payload(doc_name: str, page: int, headings: List[str], text: str) -> Dict[str, Any]:
    return {
        "doc_name": str(doc_name) if doc_name is not None else "",
        "page": int(page) if page is not None else 0,
        "headings": list(headings or []),
        "text": (text or "")[:MAX_SNIPPET_CHARS],
    }  # [web:368]
