from qdrant_client import models
from src.embeddings import BGEHybridEncoder
from src.qdrant_io import connect, query_hybrid

def main():
    query = "zero trust architecture for managed services"
    top_k = 5
    ef = 256

    enc = BGEHybridEncoder()
    q_dense = enc.encode_query_dense(query)
    q_sparse = enc.bm25_document(query)
    q_colbert = enc.encode_query_colbert(query)

    client = connect()
    hits = query_hybrid(
        client,
        name="doclib_hybrid_bgem3",
        dense_name="dense",
        query_dense=q_dense,
        top_k=top_k,
        hnsw_ef=ef,
        query_sparse=q_sparse,
        colbert_name="colbert",
        query_colbert=q_colbert,
    )
    for h in hits:
        p = h.payload or {}
        print(f"{h.score:.4f} | {p.get('doc_name')} | page {p.get('page')} | {p.get('headings')}")

if __name__ == "__main__":
    main()
    