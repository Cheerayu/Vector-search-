from dataclasses import dataclass
from typing import List

@dataclass
class PageItem:
    doc_name: str
    page: int
    text: str
    headings: List[str]
