from typing import List, Dict, Any, Optional, Any as AnyType
import uuid, json, time
from qdrant_client import QdrantClient, models

# Keep each HTTP body comfortably below default cap (~32 MB); ~28 MB headroom [web:401]
BUDGET_BYTES = 28 * 1024 * 1024

# Retry/backoff settings for long control-plane ops (create/update collection) [web:433]
CREATE_UPDATE_MAX_RETRIES = 6
CREATE_UPDATE_BACKOFF_BASE = 1.5
CREATE_UPDATE_BACKOFF_START = 2.0
CREATE_UPDATE_MAX_SLEEP = 60.0

# Very large timeout to simulate “unbounded” wait in seconds (e.g., 24 hours) [web:367][web:435]
CLIENT_TIMEOUT_SECONDS = 86400.0


def connect(url: str = "http://localhost:6333", api_key: Optional[str] = None) -> QdrantClient:
    """
    Create a REST client with a very large timeout to avoid ReadTimeouts on slow/large operations. [web:367][web:435]
    """
    return QdrantClient(
        url=url,
        api_key=api_key,
        prefer_grpc=False,
        timeout=CLIENT_TIMEOUT_SECONDS,
    )  # [web:367][web:435]


def _hnsw_diff(m: int, ef_construct: int, full_scan_threshold: int, on_disk: bool = True) -> models.HnswConfigDiff:
    return models.HnswConfigDiff(
        m=m, ef_construct=ef_construct, full_scan_threshold=full_scan_threshold, on_disk=on_disk
    )  # [web:224]


def _ensure_with_retries(op, *, desc: str) -> None:
    """
    Retry wrapper for create/update collection with exponential backoff. [web:433]
    """
    attempt = 0
    sleep = CREATE_UPDATE_BACKOFF_START
    while True:
        try:
            op()
            return
        except Exception:
            attempt += 1
            if attempt > CREATE_UPDATE_MAX_RETRIES:
                raise
            time.sleep(min(sleep, CREATE_UPDATE_MAX_SLEEP))
            sleep *= CREATE_UPDATE_BACKOFF_BASE


def ensure_hybrid_collection(
    client: QdrantClient,
    name: str,
    dense_name: str,
    dense_size: int,
    colbert_name: Optional[str] = None,
    colbert_size: Optional[int] = None,
    distance: str = "COSINE",
    m: int = 32,
    ef_construct: int = 256,
    full_scan_threshold: int = 10000,
    vectors_on_disk: bool = True,
    hnsw_on_disk: bool = True,
    on_disk_payload: Optional[bool] = True,   # enable RocksDB payload by default [web:425]
    memmap_threshold: Optional[int] = 20000,  # helps RAM during heavy ingestion [web:411]
) -> None:
    dist = getattr(models.Distance, distance)
    vectors: Dict[str, Any] = {
        dense_name: models.VectorParams(
            size=dense_size,
            distance=dist,
            hnsw_config=_hnsw_diff(m, ef_construct, full_scan_threshold, on_disk=hnsw_on_disk),
            on_disk=vectors_on_disk,
        )
    }  # [web:224]
    if colbert_name and colbert_size:
        vectors[colbert_name] = models.VectorParams(
            size=colbert_size,
            distance=dist,
            hnsw_config=_hnsw_diff(m, ef_construct, full_scan_threshold, on_disk=hnsw_on_disk),
            multivector_config=models.MultiVectorConfig(comparator=models.MultiVectorComparator.MAX_SIM),
            on_disk=vectors_on_disk,
        )  # [web:224]
    sparse_cfg = {"sparse": models.SparseVectorParams(index=models.SparseIndexParams(on_disk=True))}  # [web:224]

    def do_update():
        client.update_collection(
            collection_name=name,
            vectors_config={
                k: models.VectorParamsDiff(
                    hnsw_config=_hnsw_diff(m, ef_construct, full_scan_threshold, on_disk=hnsw_on_disk),
                    on_disk=vectors_on_disk,
                )
                for k in vectors.keys()
            },
            sparse_vectors_config=sparse_cfg,
            optimizers_config=models.OptimizersConfigDiff(memmap_threshold=memmap_threshold) if memmap_threshold else None,
            on_disk_payload=on_disk_payload,
        )

    def do_create():
        client.create_collection(
            collection_name=name,
            vectors_config=vectors,
            sparse_vectors_config=sparse_cfg,
            optimizers_config=models.OptimizersConfigDiff(memmap_threshold=memmap_threshold) if memmap_threshold else None,
            on_disk_payload=on_disk_payload,
        )

    try:
        client.get_collection(name)  # exist check [web:224]
        _ensure_with_retries(do_update, desc=f"update_collection:{name}")  # [web:433]
    except Exception:
        _ensure_with_retries(do_create, desc=f"create_collection:{name}")  # [web:433]


def _estimate_point_bytes(pt: models.PointStruct) -> int:
    try:
        s = json.dumps(pt.dict(), separators=(",", ":"), ensure_ascii=False)
        return len(s.encode("utf-8"))
    except Exception:
        return 1024


def _flush_batch(client: QdrantClient, name: str, batch: List[models.PointStruct]) -> None:
    if batch:
        client.upsert(collection_name=name, points=batch)  # server enforces service.max_request_size_mb [web:411]


def _upsert_points_under_budget(client: QdrantClient, name: str, points: List[models.PointStruct], budget_bytes: int = BUDGET_BYTES) -> None:
    batch: List[models.PointStruct] = []
    used = 0
    for pt in points:
        sz = _estimate_point_bytes(pt)
        if sz > budget_bytes:
            _flush_batch(client, name, batch)
            batch = []
            _flush_batch(client, name, [pt])
            used = 0
            continue
        if used + sz > budget_bytes:
            _flush_batch(client, name, batch)
            batch = [pt]
            used = sz
        else:
            batch.append(pt)
            used += sz
    _flush_batch(client, name, batch)


def upsert_hybrid(
    client: QdrantClient,
    name: str,
    dense_name: str,
    dense_vectors: List[List[float]],
    payloads: List[Dict[str, Any]],
    sparse_docs: Optional[List[models.Document]] = None,
    colbert_name: Optional[str] = None,
    colbert_vectors: Optional[List[List[List[float]]]] = None,
    ids: Optional[List[AnyType]] = None,
) -> None:
    points: List[models.PointStruct] = []
    for i, payload in enumerate(payloads):
        vecs: Dict[str, Any] = {dense_name: dense_vectors[i]}
        if sparse_docs:
            vecs["sparse"] = sparse_docs[i]
        if colbert_name and colbert_vectors:
            vecs[colbert_name] = colbert_vectors[i]
        pid = ids[i] if (ids and ids[i] is not None) else str(uuid.uuid4())
        points.append(models.PointStruct(id=pid, vector=vecs, payload=payload))
    _upsert_points_under_budget(client, name, points, budget_bytes=BUDGET_BYTES)  # [web:401]


def _by_id_maxscore(sets: List[List[models.ScoredPoint]], top_k: int) -> List[models.ScoredPoint]:
    best: Dict[Any, models.ScoredPoint] = {}
    for lst in sets:
        for p in lst or []:
            if p is None:
                continue
            pid = p.id
            if pid not in best or (p.score or 0.0) > (best[pid].score or 0.0):
                best[pid] = p
    return sorted(best.values(), key=lambda sp: (sp.score or 0.0), reverse=True)[:top_k]  # [web:224]


def _query_dense(client: QdrantClient, name: str, using: str, qvec: List[float], k: int, ef: int) -> List[models.ScoredPoint]:
    resp = client.query_points(
        collection_name=name,
        query=qvec,
        using=using,
        limit=k,
        with_payload=True,
        with_vectors=False,
        search_params=models.SearchParams(hnsw_ef=ef, exact=False),
    )  # [web:224]
    return getattr(resp, "points", [])


def _query_sparse_only(client: QdrantClient, name: str, doc: models.Document, k: int) -> List[models.ScoredPoint]:
    resp = client.query_points(
        collection_name=name,
        query=doc,
        using="sparse",
        limit=k,
        with_payload=True,
        with_vectors=False,
    )  # [web:224]
    return getattr(resp, "points", [])


def _query_colbert(client: QdrantClient, name: str, using: str, tokens: List[List[float]], k: int, ef: int) -> List[models.ScoredPoint]:
    resp = client.query_points(
        collection_name=name,
        query=tokens,
        using=using,
        limit=k,
        with_payload=True,
        with_vectors=False,
        search_params=models.SearchParams(hnsw_ef=ef, exact=False),
    )  # [web:224]
    return getattr(resp, "points", [])


def query_hybrid(
    client: QdrantClient,
    name: str,
    dense_name: str,
    query_dense: List[float],
    top_k: int = 5,
    hnsw_ef: int = 128,
    query_sparse: Optional[models.Document] = None,
    colbert_name: Optional[str] = None,
    query_colbert: Optional[List[List[float]]] = None,
) -> List[models.ScoredPoint]:
    legs: List[List[models.ScoredPoint]] = []
    legs.append(_query_dense(client, name, dense_name, query_dense, top_k, hnsw_ef))  # [web:224]
    if query_sparse is not None:
        legs.append(_query_sparse_only(client, name, query_sparse, top_k))  # [web:224]
    if colbert_name and query_colbert is not None:
        legs.append(_query_colbert(client, name, colbert_name, query_colbert, top_k, hnsw_ef))  # [web:224]
    return _by_id_maxscore(legs, top_k)  # [web:224]
