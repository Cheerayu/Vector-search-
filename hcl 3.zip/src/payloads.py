from typing import Dict, Any, List

MAX_SNIPPET_CHARS = 600  # balanced context with small JSON [web:368]
MAX_HEADINGS = 3         # avoid large arrays [web:224]

def make_payload(doc_name: str, page: int, headings: List[str], text: str) -> Dict[str, Any]:
    h = list(headings or [])
    if len(h) > MAX_HEADINGS:
        h = h[:MAX_HEADINGS]
    return {
        "doc_name": str(doc_name) if doc_name is not None else "",
        "page": int(page) if page is not None else 0,
        "headings": h,
        "text": (text or "")[:MAX_SNIPPET_CHARS],
    }  # [web:368]
