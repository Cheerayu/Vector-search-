from pathlib import Path
from typing import List
from .docling_convert import convert_pdf_to_pages
from .fs_utils import ensure_dir, write_text
from .doc_models import PageItem

FILES = [
    r"C:\Users\cheer\hcl\docs\capabilities-guide.pdf",
    r"C:\Users\cheer\hcl\docs\Cyber Security Managed Services.pdf",
    r"C:\Users\cheer\hcl\docs\TCS-Cyber-Security-Implementation-Services.pdf",
]

def page_block(p: PageItem) -> str:
    head_str = ", ".join(p.headings) if p.headings else "None"
    return "\n".join([
        "---------",
        "meta data",
        "---------",
        f"Doc: {p.doc_name}",
        f"Page: {p.page}",
        f"Headings: {head_str}",
        "",
        "---------",
        "respective text",
        "---------",
        p.text.strip(),
        ""
    ])

def main():
    out_dir = ensure_dir(r"C:\Users\cheer\hcl\out_txt")
    combined = out_dir / "combined.txt"
    errors = out_dir / "_errors.txt"

    all_blocks: List[str] = []
    errs: List[str] = []

    for f in FILES:
        pages, err = convert_pdf_to_pages(f)
        if err:
            errs.append(err)
            continue
        for p in pages:
            all_blocks.append(page_block(p))

    write_text(combined, "\n".join(all_blocks) if all_blocks else "No content.")
    write_text(errors, "\n".join(errs) if errs else "No errors.")
    print(f"Wrote: {combined} with {len(all_blocks)} page blocks; errors: {len(errs)}")

if __name__ == "__main__":
    main()
