from typing import List, Tuple, Dict, Any
import torch
from transformers import AutoTokenizer, AutoModel
from qdrant_client import models

# Model names
DENSE_MODEL = "BAAI/bge-m3"
# ColBERT token vector size will match the dense hidden size for simplicity
COLBERT_MODEL = "BAAI/bge-m3"

class BGEHybridEncoder:
    def __init__(self, device: str = None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(DENSE_MODEL)
        self.model = AutoModel.from_pretrained(DENSE_MODEL).to(self.device).eval()
        # ColBERT-style tokens use same model outputs but keep token embeddings without mean-pooling
        self.colbert_tokenizer = AutoTokenizer.from_pretrained(COLBERT_MODEL)
        self.colbert_model = self.model  # reuse same model weights

        # Discover dense dimension
        with torch.no_grad():
            t = self.tokenizer("probe", return_tensors="pt").to(self.device)
            h = self.model(**t).last_hidden_state  # [1, seq, hidden]
            self._dim = h.size(-1)

    def dense_dim(self) -> int:
        return self._dim

    def encode_dense(self, texts: List[str]) -> List[List[float]]:
        out = []
        with torch.no_grad():
            for txt in texts:
                t = self.tokenizer(txt, return_tensors="pt", truncation=True, max_length=512).to(self.device)
                h = self.model(**t).last_hidden_state  # [1, seq, hidden]
                v = h.mean(dim=1).squeeze(0)  # simple mean-pool for sentence embedding
                out.append(v.detach().cpu().tolist())
        return out

    def encode_query_dense(self, text: str) -> List[float]:
        return self.encode_dense([text])[0]

    def encode_colbert(self, texts: List[str]) -> List[List[List[float]]]:
        # Return list of token vectors per text: List[token_count][hidden]
        outs = []
        with torch.no_grad():
            for txt in texts:
                t = self.colbert_tokenizer(txt, return_tensors="pt", truncation=True, max_length=128).to(self.device)
                h = self.colbert_model(**t).last_hidden_state.squeeze(0)  # [seq, hidden]
                # Optionally L2-normalize token vectors to stabilize MAX_SIM
                v = torch.nn.functional.normalize(h, p=2, dim=-1)
                outs.append(v.detach().cpu().tolist())
        return outs

    def encode_query_colbert(self, text: str) -> List[List[float]]:
        return self.encode_colbert([text])[0]

    def bm25_document(self, text: str) -> models.Document:
        # Use Qdrant BM25 Document for sparse representation (server computes term weights)
        return models.Document(text=text, model="Qdrant/bm25")
