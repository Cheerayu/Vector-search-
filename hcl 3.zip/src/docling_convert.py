from pathlib import Path
from typing import List, Tuple, Dict, Set
from docling.document_converter import DocumentConverter
from .doc_models import PageItem

def _page_from_item(item) -> int:
    try:
        if getattr(item, "prov", None):
            p = item.prov[0]
            if hasattr(p, "page_no") and p.page_no is not None:
                return int(p.page_no)
    except Exception:
        pass
    return 1

def _is_heading(item) -> bool:
    try:
        labels = getattr(item, "labels", None)
        if labels and ("heading" in {str(l).lower() for l in labels}):
            return True
    except Exception:
        pass
    try:
        meta = getattr(item, "dl_meta", None) or getattr(item, "meta", None)
        if meta and isinstance(getattr(meta, "headings", None), list) and meta.headings:
            return True
    except Exception:
        pass
    return False

def _heading_level_guess(text: str) -> str:
    t = (text or "").strip()
    if not t:
        return "H2"
    if len(t) <= 40 and t.upper() == t and any(c.isalpha() for c in t):
        return "H1"
    if t[:3].strip().split(" ")[0].rstrip(".").isdigit():
        return "H2"
    if t[:1].isdigit():
        return "H3"
    return "H2"

def convert_pdf_to_pages(path: str | Path) -> Tuple[List[PageItem], str | None]:
    path = Path(path)
    try:
        converter = DocumentConverter()
        result = converter.convert(path)
        doc = result.document
    except Exception as e:
        return [], f"{path.name}: {e}"

    try:
        iterator = doc.iterate_items(doc.body, with_groups=True)
    except Exception:
        iterator = []

    page_text: Dict[int, List[str]] = {}
    page_headings: Dict[int, Set[str]] = {}

    current_page = 1
    for item, _lvl in iterator:
        pg = _page_from_item(item)
        current_page = pg or current_page

        if _is_heading(item):
            t = getattr(item, "text", None)
            heading_text = (t or "").strip()
            if not heading_text:
                try:
                    meta = getattr(item, "dl_meta", None) or getattr(item, "meta", None)
                    if meta and getattr(meta, "headings", None):
                        heading_text = str(meta.headings[0]).strip()
                except Exception:
                    pass
            if heading_text:
                level = _heading_level_guess(heading_text)
                page_headings.setdefault(current_page, set()).add(f"{level}: {heading_text}")

        label = getattr(item, "label", None)
        is_table = str(label).lower() == "table" if label else False

        if is_table:
            md = None
            try:
                md = item.export_to_markdown(doc)
            except Exception:
                md = None
            if md:
                page_text.setdefault(current_page, []).append(md.strip())
        else:
            t = getattr(item, "text", None)
            if t and t.strip():
                page_text.setdefault(current_page, []).append(t.strip())

    pages: List[PageItem] = []
    for pg in sorted(page_text.keys()):
        pages.append(
            PageItem(
                doc_name=path.name,
                page=pg,
                text="\n".join(page_text.get(pg, [])).strip(),
                headings=sorted(list(page_headings.get(pg, set())))
            )
        )

    return pages, None
