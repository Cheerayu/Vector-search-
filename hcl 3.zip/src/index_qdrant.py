from pathlib import Path
from typing import List, Tuple
from qdrant_client import models
from .docling_convert import convert_pdf_to_pages
from .payloads import make_payload
from .embeddings import BGEHybridEncoder
from .qdrant_io import connect, ensure_hybrid_collection, upsert_hybrid

# Auto-scan this folder each run; adjust for the current machine
ROOT = Path(r"C:\Users\cheer\hcl")
DOCS_DIR = ROOT / "docs"
COLLECTION = "doclib_hybrid_bgem3"

CHUNK_MAX_CHARS = 1200
CHUNK_OVERLAP_CHARS = 150

def list_pdfs(p: Path) -> List[Path]:
    p.mkdir(parents=True, exist_ok=True)
    return sorted([x for x in p.glob("*.pdf") if x.is_file()])  # [web:224]

def chunk_text(txt: str, max_chars: int = CHUNK_MAX_CHARS, overlap: int = CHUNK_OVERLAP_CHARS) -> List[str]:
    if not txt:
        return [""]
    chunks: List[str] = []
    n = len(txt)
    start = 0
    while start < n:
        end = min(start + max_chars, n)
        chunks.append(txt[start:end])
        if end >= n:
            break
        start = max(0, end - overlap)
    return chunks  # [web:224]

def page_fields(page_obj) -> Tuple[str, int, List[str], str]:
    doc_name = getattr(page_obj, "doc_name", None) or getattr(page_obj, "source_name", None) or ""
    page = int(getattr(page_obj, "page", 0) or 0)
    headings = list(getattr(page_obj, "headings", []) or [])
    text = getattr(page_obj, "text", "") or ""
    return doc_name, page, headings, text  # [web:224]

def main():
    files = list_pdfs(DOCS_DIR)
    if not files:
        print(f"No PDFs found under {DOCS_DIR}")
        return

    pages_all: List[object] = []
    errs: List[str] = []

    for f in files:
        try:
            pages, err = convert_pdf_to_pages(f)
        except Exception as e:
            errs.append(f"{f.name}: {e}")
            continue
        if err:
            errs.append(err)
        if pages:
            pages_all.extend(pages)

    if not pages_all:
        print("No pages to index.")
        for e in errs:
            print(" -", e)
        return

    chunk_payloads: List[dict] = []
    texts: List[str] = []
    for p in pages_all:
        doc_name, page, headings, text = page_fields(p)
        for idx, ch in enumerate(chunk_text(text, max_chars=CHUNK_MAX_CHARS, overlap=CHUNK_OVERLAP_CHARS)):
            payload = make_payload(doc_name, page, headings, ch)
            payload["chunk_index"] = idx
            chunk_payloads.append(payload)
            texts.append(ch)

    if not texts:
        print("No text chunks to index.")
        return

    enc = BGEHybridEncoder()
    dense_vecs = enc.encode_dense(texts)
    colbert_vecs = enc.encode_colbert(texts)
    sparse_docs = [enc.bm25_document(t) for t in texts]

    client = connect()
    dense_name = "dense"
    colbert_name = "colbert"

    ensure_hybrid_collection(
        client,
        name=COLLECTION,
        dense_name=dense_name,
        dense_size=enc.dense_dim(),
        colbert_name=colbert_name,
        colbert_size=enc.dense_dim(),
        vectors_on_disk=True,
        hnsw_on_disk=True,
        on_disk_payload=True,   # RocksDB payload on disk [web:425]
        memmap_threshold=20000,
    )  # [web:224]

    upsert_hybrid(
        client,
        name=COLLECTION,
        dense_name=dense_name,
        dense_vectors=dense_vecs,
        payloads=chunk_payloads,
        sparse_docs=sparse_docs,
        colbert_name=colbert_name,
        colbert_vectors=colbert_vecs,
    )

    print(f"Indexed {len(chunk_payloads)} chunks from {len(files)} file(s) into '{COLLECTION}'.")
    if errs:
        print("Conversion notes:")
        for e in errs:
            print(" -", e)

if __name__ == "__main__":
    main()
