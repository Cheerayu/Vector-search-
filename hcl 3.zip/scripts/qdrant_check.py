import json
import urllib.request
from qdrant_client import QdrantClient

NAME = "doclib_hybrid_bgem3"
BASE = "http://localhost:6333"

def http_get(path: str):
    with urllib.request.urlopen(f"{BASE}{path}") as r:
        return json.loads(r.read().decode("utf-8"))

def main():
    # 1) Health via HTTP (works across server/client versions)
    try:
        root = http_get("/")
        print("Health OK:", root)
    except Exception as e:
        print("Health check failed:", e)
        return

    client = QdrantClient(url=BASE)

    # 2) List collections
    try:
        cols = client.get_collections()
        names = [c.name for c in cols.collections]
        print("Collections:", names)
        if NAME not in names:
            print(f"Collection '{NAME}' not found. Indexing may not have completed.")
            return
    except Exception as e:
        print("get_collections failed:", e)
        return

    # 3) Collection schema
    try:
        col = client.get_collection(NAME)
        print("\nCollection:", NAME)
        print("Vectors config:", col.vectors)
        # Sparse config can be on this attr or inside config depending on client version
        sparse_cfg = getattr(col, "sparse_vectors_config", None) or getattr(col, "config", None)
        print("Sparse config:", sparse_cfg)
    except Exception as e:
        print("get_collection failed:", e)
        return

    # 4) Counts
    try:
        info = client.get_collection_info(NAME)
        print("Status:", info.status, "| Points count:", info.points_count)
    except Exception as e:
        print("get_collection_info failed:", e)

    # 5) Inspect a sample point with vectors
    try:
        points, _ = client.scroll(NAME, limit=1, with_vectors=True)
        if points:
            p = points[0]
            print("\nSample point id:", p.id)
            print("Payload keys:", sorted((p.payload or {}).keys()))
            vec = p.vector
            if isinstance(vec, dict):
                print("Vector keys:", sorted(list(vec.keys())))  # expect ['colbert','dense','sparse']
            else:
                print("Vector present type:", type(vec))
        else:
            print("No points returned by scroll.")
    except Exception as e:
        print("scroll failed:", e)

if __name__ == "__main__":
    main()
